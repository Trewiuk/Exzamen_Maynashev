﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace maynashev
{
    /// <summary>
    /// Логика взаимодействия для OrderPage.xaml
    /// </summary>
    public partial class OrderPage : Page
    {
        public OrderPage()
        {
            InitializeComponent();
            DataGridOrder.ItemsSource = AppData.db.Order.ToList();
            CmbPunkt.ItemsSource = AppData.db.Punkt.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditOrderPage());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены?","Предупреждение",MessageBoxButton.YesNo,MessageBoxImage.Question)==MessageBoxResult.Yes)
            {
            var CurrentOrder = DataGridOrder.SelectedItem as Order;
            AppData.db.Order.Remove(CurrentOrder);
            AppData.db.SaveChanges();
            MessageBox.Show("Данные удалены");
            DataGridOrder.ItemsSource = AppData.db.Order.ToList();
            }
            
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new LoginPage());
        }

        private void filterBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (filterBox.Text.Length > 0)
            {
                labelDate.Content = "";
                DataGridOrder.ItemsSource = AppData.db.Order.Where(x => x.Date_Dost.ToString().StartsWith(filterBox.Text)).ToList();
                
            }
            else
            {
                DataGridOrder.ItemsSource = AppData.db.Order.ToList();
            }
           
            
        }

        private void CmbPunkt_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var CurrentStreet = CmbPunkt.SelectedItem as Punkt;
            DataGridOrder.ItemsSource = AppData.db.Order.Where(x => x.Punkt1.Street.ToString().StartsWith(CmbPunkt.Text)).ToList();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            CmbPunkt.Text = "";
            DataGridOrder.ItemsSource = AppData.db.Order.ToList();
        }

        //private void Button_Click_3(object sender, RoutedEventArgs e)
        //{
        //    CmbPunkt.SelectedIndex = -1;
        //    CmbPunkt.Text = "";
        //    DataGridOrder.ItemsSource = AppData.db.Order.ToList();
        //}
    }
}

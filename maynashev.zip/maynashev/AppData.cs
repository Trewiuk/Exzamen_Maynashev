﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maynashev
{
    class AppData
    {
        public static MaynashevEntities1 db = new MaynashevEntities1();
    }
}
